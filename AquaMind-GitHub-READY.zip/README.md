# AquaMind — Smart Fish Farm Dashboard

This GitHub Pages-ready project contains a standalone `index.html` with all CSS and JavaScript embedded.

## Publish
1. Create a public GitHub repository named `aquamind`.
2. Upload `index.html` (and this README) into its repository root.
3. In Settings > Pages, select Deploy from a branch, `main`, `/ (root)` and Save.
4. Visit `https://YOUR_USERNAME.github.io/aquamind/`.

This is an offline-first demo prototype; records are kept per-browser using localStorage.
